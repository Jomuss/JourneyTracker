package com.joemoss.firebasetest;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

import static com.joemoss.firebasetest.LoginActivity.LOGGED_IN;

public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth fAuth;
    private EditText userPassword;
    private EditText userPasswordConfirm;
    private EditText userEmail;
    private Button registerButton;

    public RegisterActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        fAuth = FirebaseAuth.getInstance();
        userEmail = findViewById(R.id.email_register_field);
        userPassword = findViewById(R.id.password_register_field);
        userPasswordConfirm = findViewById(R.id.password_confirm_field);
        registerButton = findViewById(R.id.register_button);

        registerButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                registerUser();
            }
        });


    }

    //Handles registering a user
    public void registerUser(){
        String email = userEmail.getText().toString().trim();
        String password = userPassword.getText().toString().trim();

        //if either field is empty notify user
       //if(email.isEmpty() || password.isEmpty()){ }\

        if(checkPassword()) {
            fAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            try {
                                if (task.isSuccessful()) {
                                    Toast.makeText(RegisterActivity.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                                    createUserEntry();
                                    setResult(LOGGED_IN);
                                    startMainViewActivity();
                                    finish();

                                } else {
                                    Toast.makeText(RegisterActivity.this, "There was an error registering you", Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });

        }
        else{
            Toast.makeText(RegisterActivity.this, "Your passwords do not match", Toast.LENGTH_SHORT).show();
        }
    }

    private void startMainViewActivity(){
        Intent mainViewIntent = new Intent(this, MainViewActivity.class);
        startActivity(mainViewIntent);
    }

    private void createUserEntry(){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String uID = fAuth.getCurrentUser().getUid();
        Map<String, Object> userData = new HashMap<>();
        userData.put("email", userEmail.getText().toString());
        db.collection("users").document(uID).set(userData)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("addUserData", "User successfully registered and data added");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("addUserData", "User successfully registered but data could not be added");
                    }
                });
    }


    private boolean checkPassword(){
        String pass = userPassword.getText().toString();
        String passConfirm = userPasswordConfirm.getText().toString();

        if(pass.equals(passConfirm)){return true;}

        return false;
    }






}
